a1 = ".pdf"
a2 = ".jpeg"
a3 = ".png"
a4 = ".ico"
b1 = "PDF"
b2 = "JPEG"
b3 = "PNG"
b4 = "ICO"


sub = str()
new_name = ""

text = " "


print("make sure the image is in the right location!")
print("Look below")


import os
print(os.getcwd())  # Prints the current working directory

Conversion = int(input("What converstion? : "))


while Conversion >= 5 or Conversion <= 0:
    Conversion = int(input("Invalid converstion, What converstion?: "))

if str(Conversion) == text:
    print("error")


if Conversion == 1:
    Conversion = str(a1)
    sub = b1
elif Conversion == 2:
    Conversion = str(a2)
    sub = b2
elif Conversion == 3:
    Conversion = str(a3)
    sub = b3
elif Conversion == 4:
    Conversion = str(a4)
    sub = b4
new_name = input("What name will it be? ")






from PIL import Image

im = Image.open("image.png")

im.save(f"{new_name}{(Conversion)}", f"{(sub)}")

print("Converted successfully!")
print("Check your Folder where you dropped the image")

