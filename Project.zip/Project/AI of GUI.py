#NOt my version



import tkinter as tk
from tkinter import Menu, filedialog, messagebox
import os
import webbrowser
from PIL import Image, ImageTk


# Functions for the Menu
def file_opener():
    # Open the file dialog and return the selected file path
    file = filedialog.askopenfile(mode="r", filetypes=[("Image Files", "*.png")])
    if file:
        return file.name
    return None

def link():
    webbrowser.open_new_tab("https://github.com/GeneralGarfield")

def saveas():
    filedialog.asksaveasfilename()

def imagetest():
    file_path = file_opener()  # Get the file path from file_opener
    if file_path:
        image = Image.open(file_path)  # Open the image
        image2 = ImageTk.PhotoImage(image)  # Convert to a PhotoImage object
        label = tk.Label(root, image=image2)  # Create a label with the image
        label.image = image2  # Keep a reference to the image to prevent garbage collection
        label.pack()  # Pack the label into the window

# Opens file in the same directory
directory_path = os.path.dirname(__file__)
file_path = os.path.join(directory_path, 'test.ico')

# Creates the main Window and Icon
root = tk.Tk()
root.title("Converter")
root.iconbitmap(file_path)
root.geometry("580x480")

# This starts the menu bar with the option menu. 
menubar = Menu(root)

# This is the selection for the File category
filemenu = Menu(menubar, tearoff=0)

filemenu.add_command(label="Open File", command=imagetest)  # Use imagetest to open and display an image
filemenu.add_command(label="View Conversions", command=lambda: print("Placeholder"))  # Example placeholder
filemenu.add_command(label="Settings", command=lambda: print("Placeholder"))  # Example placeholder
filemenu.add_command(label="Exit", command=root.destroy)

menubar.add_cascade(label="File", menu=filemenu)

# Help Option
Help = Menu(menubar, tearoff=0)
Help.add_command(label="Tutorial", command=lambda: print("Placeholder"))  # Example placeholder
menubar.add_cascade(label="Help", menu=Help)

# About me
About = Menu(menubar, tearoff=0)
About.add_command(label="About Me", command=lambda: print("Placeholder"))  # Display an image in 'About Me'
About.add_command(label="Github", command=link)
menubar.add_cascade(label="About", menu=About)

# These last two go last to run the menubar DONT CHANGE IT
root.config(menu=menubar)

# Run the main loop
root.mainloop()